﻿# Place ffmpeg (no extension) here for macOS - chmod +x required
