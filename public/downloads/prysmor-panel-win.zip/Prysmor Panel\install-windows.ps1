﻿# Prysmor Panel - Windows Installer Script
Write-Host ""
Write-Host "=== Prysmor Panel Installer ===" -ForegroundColor Green
Write-Host ""
$dest = "$env:APPDATA\Adobe\CEP\extensions\prysmor-panel"
$src  = Join-Path $PSScriptRoot "prysmor-panel"
foreach ($ver in @("CSXS.10","CSXS.11","CSXS.12")) {
    $key = "HKCU:\Software\Adobe\$ver"
    if (-not (Test-Path $key)) { New-Item -Path $key -Force | Out-Null }
    Set-ItemProperty -Path $key -Name "PlayerDebugMode" -Value 1 -Type DWord
    Write-Host "  + $ver PlayerDebugMode = 1" -ForegroundColor Cyan
}
if (Test-Path $dest) { Remove-Item $dest -Recurse -Force; Write-Host "  + Removed old version" }
New-Item -ItemType Directory -Force -Path (Split-Path $dest) | Out-Null
Copy-Item -Recurse $src $dest
Write-Host "  + Installed to $dest" -ForegroundColor Green
Write-Host ""
Write-Host "Done! Restart Premiere Pro, then: Window > Extensions > Prysmor" -ForegroundColor Green
Write-Host ""
Read-Host "Press Enter to close"
