/**
 * Prysmor Panel — ExtendScript Host
 * Runs inside Adobe Premiere Pro's scripting engine.
 * Called via CSInterface.evalScript() from the panel JS.
 */

// ─── Import file into the active Premiere project ─────────────────────────────
function importFile(filePath) {
  try {
    if (typeof app === 'undefined') {
      return 'error: Adobe scripting engine not available.';
    }
    if (!app.project) {
      return 'error: No project is open. Please open or create a Premiere project first.';
    }

    app.project.importFiles(
      [filePath],
      true,                    // suppressUI
      app.project.rootItem,    // target bin
      false                    // importAsNumberedStills
    );

    return 'success';
  } catch (e) {
    return 'error: ' + e.message;
  }
}

// ─── Import and insert clip at current playhead position ──────────────────────
function insertToTimeline(filePath) {
  try {
    if (typeof app === 'undefined') {
      return 'error: Adobe scripting engine not available.';
    }
    if (!app.project) {
      return 'error: No project is open.';
    }

    var activeSequence = app.project.activeSequence;
    if (!activeSequence) {
      return 'error: No active sequence. Please open a sequence in the Timeline first.';
    }
    if (activeSequence.videoTracks.numTracks === 0) {
      return 'error: No video tracks found in the active sequence.';
    }

    // Import file
    app.project.importFiles([filePath], true, app.project.rootItem, false);

    // Resolve file name (cross-platform: handle / and \)
    var parts = filePath.replace(/\\/g, '/').split('/');
    var fileName = parts[parts.length - 1];

    // Locate the newly imported item in the project root
    var projectItem = null;
    var rootChildren = app.project.rootItem.children;
    for (var i = 0; i < rootChildren.numItems; i++) {
      if (rootChildren[i].name === fileName) {
        projectItem = rootChildren[i];
        break;
      }
    }

    if (!projectItem) {
      return 'error: Clip was imported but could not be located in the project panel.';
    }

    // Insert at playhead on the first video track
    var track = activeSequence.videoTracks[0];
    var insertTime = activeSequence.getPlayerPosition();
    track.insertClip(projectItem, insertTime.seconds);

    return 'success';
  } catch (e) {
    return 'error: ' + e.message;
  }
}

// ─── Return host app metadata ─────────────────────────────────────────────────
function getAppInfo() {
  try {
    var info = {
      appName:     app.name    || 'Adobe Premiere Pro',
      appVersion:  app.version || 'unknown',
      hasProject:  !!(app.project),
      hasSequence: !!(app.project && app.project.activeSequence),
      sequenceName: ''
    };
    if (info.hasSequence) {
      info.sequenceName = app.project.activeSequence.name;
    }
    return JSON.stringify(info);
  } catch (e) {
    return JSON.stringify({ error: e.message });
  }
}
