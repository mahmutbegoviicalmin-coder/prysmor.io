# Prysmor — Adobe Premiere Pro CEP Panel

AI-powered VFX generation panel for Adobe Premiere Pro (Windows & macOS).

---

## File Structure

```
prysmor-panel/
├── CSXS/
│   └── manifest.xml          Extension manifest (CEP config)
├── panel/
│   ├── lib/
│   │   └── CSInterface.js    Adobe CEP bridge (stub — see note below)
│   ├── index.html            Panel UI
│   ├── styles.css            Dark premium UI styles
│   ├── main.js               Panel logic (JS)
│   └── host.jsx              ExtendScript (runs inside Premiere)
├── .debug                    Dev mode debug config
└── README.md
```

---

## Install — Development (Unsigned)

### Step 1 — Enable unsigned extensions in Premiere

**Windows:**
```
HKEY_CURRENT_USER\Software\Adobe\CSXS.10
  → Add DWORD: PlayerDebugMode = 1
```

**macOS:**
```
defaults write com.adobe.CSXS.10 PlayerDebugMode 1
```

> Replace `CSXS.10` with your CEP version (e.g. CSXS.11 for Premiere 2022+).

### Step 2 — Copy panel to the CEP extensions folder

**Windows:**
```
C:\Users\<you>\AppData\Roaming\Adobe\CEP\extensions\prysmor-panel\
```

**macOS:**
```
~/Library/Application Support/Adobe/CEP/extensions/prysmor-panel/
```

Copy the entire `prysmor-panel/` folder into that location.

### Step 3 — Launch Premiere Pro

Go to **Window → Extensions → Prysmor** to open the panel.

---

## CSInterface.js Note

The `panel/lib/CSInterface.js` is a minimal stub for development.  
For production, replace it with the full official version from Adobe:  
→ https://github.com/Adobe-CEP/CEP-Resources/blob/master/CEP_11.x/CSInterface.js

---

## Build Distributions (Signed ZXP)

To sign and package the extension:

1. Download **ZXPSignCmd** from Adobe:  
   https://github.com/Adobe-CEP/CEP-Resources/tree/master/ZXPSignCMD

2. Create a self-signed certificate:
   ```
   ZXPSignCmd -selfSignedCert US CA Prysmor prysmor password cert.p12
   ```

3. Package:
   ```
   ZXPSignCmd -sign prysmor-panel/ prysmor-panel.zxp cert.p12 password
   ```

4. The `.zxp` file works on both Windows and macOS — rename for distribution:
   - `prysmor-panel-win.zxp`
   - `prysmor-panel-mac.zxp`

Install `.zxp` files using **Adobe Exchange** or **ZXP Installer**:  
→ https://aescripts.com/learn/zxp-installer/

---

## API Endpoints Used

| Method | Endpoint              | Purpose               |
|--------|-----------------------|-----------------------|
| GET    | /api/user/me          | Verify API key + load user |
| POST   | /api/generate         | Generate VFX clip     |
| POST   | /api/device/register  | Register CEP device   |

---

## User Flow

1. Open Premiere Pro → Window → Extensions → Prysmor
2. Click "Open Prysmor Login" → sign in via browser
3. Paste API key from dashboard
4. Enter a VFX prompt, select aspect ratio + duration
5. Click **Generate VFX**
6. Click **Import to Project** → clip appears in Project panel
7. Click **Insert to Timeline** → clip placed at playhead
