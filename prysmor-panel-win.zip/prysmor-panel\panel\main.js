'use strict';

// ─── Constants ────────────────────────────────────────────────────────────────

const BASE_URL = 'https://prysmor.com';
const STORAGE_KEY = 'prysmor_api_key';

// ─── State ────────────────────────────────────────────────────────────────────

const state = {
  apiKey:      null,
  user:        null,
  usage:       { used: 0, limit: 100 },
  result:      null,
  generating:  false,
  settingsOpen: false,
  _genTimer:   null
};

// ─── CEP Interface ────────────────────────────────────────────────────────────

let cs;

function initCS() {
  try {
    cs = new CSInterface();
  } catch (_) {
    // Outside CEP — use graceful fallback (e.g. browser testing)
    cs = {
      evalScript: function (script, cb) {
        console.warn('[Prysmor] evalScript (no CEP):', script);
        if (cb) cb('error: not in CEP environment');
      },
      openURLInDefaultBrowser: function (url) { window.open(url, '_blank'); },
      getHostEnvironment: function () { return { appName: 'PPRO', appVersion: '0.0' }; }
    };
  }
}

// ─── Boot ─────────────────────────────────────────────────────────────────────

window.addEventListener('DOMContentLoaded', function () {
  initCS();
  bindEvents();
  checkSavedSession();
});

// ─── Session ──────────────────────────────────────────────────────────────────

function checkSavedSession() {
  const saved = localStorage.getItem(STORAGE_KEY);
  if (saved) {
    state.apiKey = saved;
    connectWithKey(saved);
  } else {
    showView('login');
  }
}

async function connectWithKey(apiKey) {
  showConnecting(true);
  try {
    const res = await fetch(BASE_URL + '/api/user/me', {
      headers: { 'Authorization': 'Bearer ' + apiKey }
    });

    if (!res.ok) throw new Error('Invalid API key (HTTP ' + res.status + ')');

    const data = await res.json();

    state.apiKey = apiKey;
    state.user   = data.user   || {};
    state.usage  = data.usage  || { used: 0, limit: 100 };

    localStorage.setItem(STORAGE_KEY, apiKey);
    showView('main');
    renderUserCard();
    renderUsage();
    registerDevice();

  } catch (err) {
    localStorage.removeItem(STORAGE_KEY);
    state.apiKey = null;
    showView('login');
    showToast(err.message || 'Connection failed', 'error');
  } finally {
    showConnecting(false);
  }
}

function logout() {
  localStorage.removeItem(STORAGE_KEY);
  Object.assign(state, { apiKey: null, user: null, result: null, generating: false });
  toggleSettings(false);
  showView('login');
  // Reset generate UI
  setGenerating(false);
  el('section-result').classList.add('hidden');
  el('prompt').value = '';
  el('char-count').textContent = '0';
}

// ─── Device Registration ──────────────────────────────────────────────────────

function registerDevice() {
  let env = {};
  try { env = cs.getHostEnvironment() || {}; } catch (_) {}

  fetch(BASE_URL + '/api/device/register', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + state.apiKey
    },
    body: JSON.stringify({
      deviceName:  (env.appName || 'Adobe Premiere Pro') + ' — CEP Panel',
      os:          navigator.platform || 'unknown',
      appVersion:  env.appVersion || 'unknown'
    })
  }).catch(function () { /* non-critical */ });
}

// ─── Generate ────────────────────────────────────────────────────────────────

async function generate() {
  const prompt      = el('prompt').value.trim();
  const aspectRatio = el('aspect-ratio').value;
  const duration    = el('duration').value;

  if (!prompt) {
    showToast('Please enter a prompt', 'error');
    el('prompt').focus();
    return;
  }

  if (!state.apiKey) {
    showToast('Please sign in first', 'error');
    return;
  }

  setGenerating(true);

  const statuses = [
    'Analyzing prompt…',
    'Building scene composition…',
    'Generating VFX frames…',
    'Applying cinematic color grade…',
    'Rendering final output…',
    'Almost there…'
  ];
  let si = 0;
  state._genTimer = setInterval(function () {
    if (si < statuses.length) setGenStatus(statuses[si++]);
  }, 1800);

  try {
    const res = await fetch(BASE_URL + '/api/generate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + state.apiKey
      },
      body: JSON.stringify({
        prompt:      prompt,
        aspectRatio: aspectRatio,
        duration:    parseInt(duration, 10),
        userToken:   state.apiKey
      })
    });

    clearInterval(state._genTimer);

    if (!res.ok) {
      const errData = await res.json().catch(function () { return {}; });
      throw new Error(errData.error || 'Generation failed (HTTP ' + res.status + ')');
    }

    const data = await res.json();
    state.result = data;
    state.usage.used = (state.usage.used || 0) + 1;

    setGenerating(false);
    showResult(data, duration, aspectRatio);
    renderUsage();
    showToast('VFX generated successfully!', 'success');

  } catch (err) {
    clearInterval(state._genTimer);
    setGenerating(false);
    showToast(err.message || 'Generation failed', 'error');
  }
}

function setGenerating(active) {
  state.generating = active;

  el('btn-generate').disabled = active;
  el('btn-generate').style.display = active ? 'none' : '';
  el('gen-state').classList.toggle('hidden', !active);

  if (active) {
    // Restart progress bar animation
    const bar = el('gen-bar');
    bar.style.animation = 'none';
    void bar.offsetWidth; // reflow
    bar.style.animation = '';
    setGenStatus('Initializing generation…');
    el('section-result').classList.add('hidden');
  }
}

function setGenStatus(text) {
  const node = el('gen-status-text');
  if (node) node.textContent = text;
}

// ─── Result ───────────────────────────────────────────────────────────────────

function showResult(data, duration, aspectRatio) {
  const section = el('section-result');
  section.classList.remove('hidden');

  const thumb       = el('result-thumb');
  const placeholder = el('result-placeholder');
  const thumbUrl    = data.thumbnail || data.previewUrl || '';

  if (thumbUrl) {
    thumb.src = thumbUrl;
    thumb.classList.remove('hidden');
    placeholder.classList.add('hidden');
  } else {
    thumb.classList.add('hidden');
    placeholder.classList.remove('hidden');
  }

  el('chip-duration').textContent = duration + 's';
  el('chip-res').textContent = arToRes(aspectRatio);

  section.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function arToRes(ar) {
  const map = { '16:9': '1920×1080', '9:16': '1080×1920', '1:1': '1080×1080', '4:3': '1440×1080', '2.39:1': '2560×1072' };
  return map[ar] || '1920×1080';
}

// ─── Premiere Actions ─────────────────────────────────────────────────────────

function importToProject() {
  if (!state.result) return;

  const path = state.result.filePath || state.result.downloadUrl || state.result.url || '';
  if (!path) { showToast('No file path in API response', 'error'); return; }

  const escaped = path.replace(/\\/g, '/').replace(/"/g, '\\"');
  cs.evalScript('importFile("' + escaped + '")', function (result) {
    if (result && result.indexOf('error') === 0) {
      showToast(result.replace('error: ', ''), 'error');
    } else {
      showToast('Clip imported to project panel!', 'success');
    }
  });
}

function insertToTimeline() {
  if (!state.result) return;

  const path = state.result.filePath || state.result.downloadUrl || state.result.url || '';
  if (!path) { showToast('No file path in API response', 'error'); return; }

  const escaped = path.replace(/\\/g, '/').replace(/"/g, '\\"');
  cs.evalScript('insertToTimeline("' + escaped + '")', function (result) {
    if (result && result.indexOf('error') === 0) {
      showToast(result.replace('error: ', ''), 'error');
    } else {
      showToast('Clip inserted to active timeline!', 'success');
    }
  });
}

function downloadResult() {
  if (!state.result) return;
  const url = state.result.downloadUrl || state.result.url || '';
  if (url) cs.openURLInDefaultBrowser(url);
  else showToast('Download URL not available', 'error');
}

function previewResult() {
  if (!state.result) return;
  const url = state.result.previewUrl || state.result.url || '';
  if (url) cs.openURLInDefaultBrowser(url);
}

// ─── Render Helpers ───────────────────────────────────────────────────────────

function renderUserCard() {
  const u = state.user || {};
  const name  = u.firstName || u.name || u.email || 'User';
  const first = name.split(' ')[0];
  const plan  = u.plan || 'Creator';

  el('user-name').textContent    = first;
  el('user-avatar').textContent  = first.charAt(0).toUpperCase();
  el('plan-badge').textContent   = capitalize(plan) + ' Plan';
}

function renderUsage() {
  const used  = state.usage.used  || 0;
  const limit = state.usage.limit || 100;
  const pct   = Math.min(Math.round((used / limit) * 100), 100);

  el('usage-used').textContent    = used;
  el('usage-limit').textContent   = limit;
  el('progress-fill').style.width = pct + '%';
}

// ─── UI ───────────────────────────────────────────────────────────────────────

function showView(name) {
  el('view-login').classList.toggle('hidden', name !== 'login');
  el('view-main').classList.toggle('hidden',  name !== 'main');
}

function showConnecting(show) {
  el('connecting-overlay').classList.toggle('hidden', !show);
}

let _toastTimer;
function showToast(msg, type) {
  const toast = el('toast');
  const icons = { success: '✓', error: '✕', info: 'ℹ' };

  el('toast-icon').textContent = icons[type] || 'ℹ';
  el('toast-text').textContent = msg;
  toast.className = 'toast ' + (type || 'info');

  clearTimeout(_toastTimer);
  _toastTimer = setTimeout(function () { toast.classList.add('hidden'); }, 3800);
}

function toggleSettings(force) {
  const menu    = el('settings-menu');
  const chevron = el('settings-chevron');
  const open    = (force !== undefined) ? force : menu.classList.contains('hidden');

  menu.classList.toggle('hidden', !open);
  chevron.classList.toggle('open', open);
  state.settingsOpen = open;
}

// ─── Events ───────────────────────────────────────────────────────────────────

function bindEvents() {
  // Login
  el('btn-open-login').addEventListener('click', function () {
    cs.openURLInDefaultBrowser(BASE_URL + '/login');
  });

  el('btn-connect').addEventListener('click', function () {
    const key = el('api-key-input').value.trim();
    if (!key) { showToast('Please enter your API key', 'error'); return; }
    connectWithKey(key);
  });

  el('api-key-input').addEventListener('keydown', function (e) {
    if (e.key === 'Enter') el('btn-connect').click();
  });

  el('btn-toggle-key').addEventListener('click', function () {
    const inp = el('api-key-input');
    const show = inp.type === 'password';
    inp.type = show ? 'text' : 'password';
    this.textContent = show ? '🙈' : '👁';
  });

  el('link-get-key').addEventListener('click', function (e) {
    e.preventDefault();
    cs.openURLInDefaultBrowser(BASE_URL + '/dashboard/api-keys');
  });

  // Prompt char count
  el('prompt').addEventListener('input', function () {
    el('char-count').textContent = this.value.length;
  });

  // Generate
  el('btn-generate').addEventListener('click', generate);

  el('btn-new-gen').addEventListener('click', function () {
    el('section-result').classList.add('hidden');
    state.result = null;
    el('prompt').focus();
  });

  // Result actions
  el('btn-import').addEventListener('click', importToProject);
  el('btn-insert').addEventListener('click', insertToTimeline);
  el('btn-download').addEventListener('click', downloadResult);
  el('btn-preview').addEventListener('click', previewResult);

  // Settings
  el('btn-scroll-settings').addEventListener('click', function () {
    el('section-settings').scrollIntoView({ behavior: 'smooth' });
    toggleSettings(true);
  });

  el('settings-trigger').addEventListener('click', function () { toggleSettings(); });
  el('btn-logout').addEventListener('click', logout);

  el('btn-dashboard').addEventListener('click', function () {
    cs.openURLInDefaultBrowser(BASE_URL + '/dashboard');
  });

  el('btn-updates').addEventListener('click', function () {
    cs.openURLInDefaultBrowser(BASE_URL + '/downloads');
  });

  // Footer links
  el('link-docs').addEventListener('click', function (e) {
    e.preventDefault();
    cs.openURLInDefaultBrowser(BASE_URL + '/docs');
  });

  el('link-terms').addEventListener('click', function (e) {
    e.preventDefault();
    cs.openURLInDefaultBrowser(BASE_URL + '/terms');
  });
}

// ─── Utils ────────────────────────────────────────────────────────────────────

function el(id) { return document.getElementById(id); }

function capitalize(s) {
  return s ? s.charAt(0).toUpperCase() + s.slice(1).toLowerCase() : '';
}
